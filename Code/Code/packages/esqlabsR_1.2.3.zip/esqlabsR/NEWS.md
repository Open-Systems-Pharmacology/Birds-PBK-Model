# esqlabsR 2.0.0

BREAKING CHANGES

# esqlabsR 1.0.0

- Initial release of the package.
